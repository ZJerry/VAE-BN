filename = 'det_'+string(dataname)+'_'+string(adv_name)+'_all2'
% file = 'a'
save(['../data/',char(filename)],'cls')